Product: Living Hinge Patterns, version 1.0, September 2014
Designer: Scott Austin, scotta@obrary.com
Support:  support@obrary.com
Distributed by:  Obrary, Inc.  http://obrary.com.  Obrary is a marketplace of products collaboratively designed by the community. These products can be produced by anyone, amateur or professional manufacturer, wherever economically or locally practical.

Description:
The living hinge patterns are meant to printed on a laser cutter.  You can use them with the material of your choirce.

Files included in this package:
 - LivingHingePatterns.skp - this is the model of the patterns in SketchUp.  SketchUp can be installed for free at http://www.sketchup.com/download
 - DXF files for each pattern and one DXF file that shows all patterns
 - PDF files for each pattern and one PDF file that shows all patterns
 - ReadMe.txt - this file